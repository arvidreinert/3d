Thank you for using the free version of my work, "The Japan Collection: Japanese City". The complete version, including new tiles for expanding your city can be found below:

https://guttykreum.itch.io/japanese-town